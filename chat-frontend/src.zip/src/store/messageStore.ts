// src/store/messageStore.ts
import { create } from "zustand";
import { sendMessage, getHistory } from "../services/messages";

export interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  body: string;
  created_at: string;
  read: boolean;
  conversation_id: string | null;
}

interface MessageState {
  messages: Message[];
  loading: boolean;
  fetchHistory: (otherUserId: string) => Promise<void>;
  sendNewMessage: (receiver_id: string, body: string) => Promise<void>;
  addOne: (msg: Message) => void;
}

export const useMessageStore = create<MessageState>((set, get) => ({
  messages: [],
  loading: false,

  fetchHistory: async (otherUserId) => {
    set({ loading: true });
    try {
      const res = await getHistory(otherUserId);
      // backend returns newest first; reverse so UI shows top -> bottom
      const data: Message[] = res.data || [];
      set({ messages: data.slice().reverse(), loading: false });
    } catch (e) {
      console.error(e);
      set({ loading: false });
    }
  },

  sendNewMessage: async (receiver_id, body) => {
    try {
      const res = await sendMessage(receiver_id, body);
      // optimistic append
      const current = get().messages;
      if (!current.find((m) => m.id === res.data.id)) {
        set({ messages: [...current, res.data] });
      }
    } catch (e) {
      console.error(e);
      alert("Failed to send message");
    }
  },

  addOne: (msg) =>
  set((state) => {
    if (state.messages.find((m) => m.id === msg.id)) return state;
    return { messages: [...state.messages, msg] };
  }),
}));
