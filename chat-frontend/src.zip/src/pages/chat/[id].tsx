import { useEffect, useState, useRef } from "react";
import { useRouter } from "next/router";
import { useMessageStore } from "../../store/messageStore";
import { useAuthStore } from "../../store/authStore";
import { getRealtimeClient } from "../../lib/supabaseClient";
import type { Message } from "../../store/messageStore";
import type { RealtimePostgresInsertPayload } from "@supabase/supabase-js";


export default function ChatPage() {
  const router = useRouter();
  const { id: otherUserId } = router.query;
  const supabase = getRealtimeClient();

  const { user, fetchUser } = useAuthStore();
  const { messages, fetchHistory, sendNewMessage, addOne } = useMessageStore();

  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // ----------------------------
  // 🧩 INITIAL LOGGING
  // ----------------------------
  console.log("🔍 ChatPage loaded");
  console.log("router.isReady:", router.isReady);
  console.log("router.query.id:", router.query.id);
  console.log("user:", user);

  // ----------------------------
  // 🧠 Ensure user is fetched
  // ----------------------------
  useEffect(() => {
    if (!user) {
      console.log("🔄 User missing, fetching profile...");
      fetchUser();
    } else {
      console.log("✅ User already present:", user);
    }
  }, [user]);

  // ----------------------------
  // 📜 Load chat history
  // ----------------------------
  useEffect(() => {
    if (otherUserId && typeof otherUserId === "string") {
      fetchHistory(otherUserId);
    }
  }, [otherUserId, fetchHistory]);

  // ----------------------------
  // ⬇️ Scroll to bottom on message updates
  // ----------------------------
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    console.log("📜 Messages updated, scrolled to bottom.");
  }, [messages]);

  // ----------------------------
  // ⚡ Setup realtime subscription
  // ----------------------------
useEffect(() => {
  if (!router.isReady || !user?.id || !otherUserId) return;

  console.log("⚡ Subscribing for realtime messages between:", user.id, "and", otherUserId);
  const supabase = getRealtimeClient();

  // Create a unique channel for this conversation
  const channel = supabase
    .channel(`messages:conversation:${user.id}:${otherUserId}`)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "messages",
        filter: `or(
          and(sender_id.eq.${user.id},receiver_id.eq.${otherUserId}),
          and(sender_id.eq.${otherUserId},receiver_id.eq.${user.id})
        )`,
      },
      (payload: RealtimePostgresInsertPayload<Message>) => {
  console.log("💬 New realtime message:", payload.new);
  addOne(payload.new);
}
    )
    .subscribe((status) => console.log("📡 Realtime subscription status:", status));

  return () => {
    console.log("🧹 Unsubscribing realtime channel");
    supabase.removeChannel(channel);
  };
}, [router.isReady, user?.id, otherUserId]);

  // ----------------------------
  // ✉️ Handle Send Message
  // ----------------------------
  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    await sendNewMessage(otherUserId as string, newMessage.trim());
    setNewMessage("");
  };

  // ----------------------------
  // 🧱 UI RENDER
  // ----------------------------
  return (
    <div className="flex flex-col h-screen bg-gray-100">
      {/* Header */}
      <div className="p-4 bg-blue-600 text-white font-semibold text-lg flex items-center">
        <button onClick={() => router.push("/connections")} className="mr-4">
          ←
        </button>
        Chat with {otherUserId}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 && (
          <p className="text-gray-400 text-center">No messages yet.</p>
        )}
        {messages.map((m) => {
  const mine = String(m.sender_id) === String(user?.id);
  return (
    <div
      key={m.id}
      className={`flex ${mine ? "justify-end" : "justify-start"}`}
    >
      <div
        className={`p-3 rounded-2xl max-w-xs break-words shadow ${
          mine
            ? "bg-blue-500 text-white rounded-br-none"
            : "bg-white text-gray-900 rounded-bl-none border"
        }`}
      >
        <p>{m.body}</p>
        <div className="text-[10px] mt-1 opacity-70 text-right">
          {new Date(m.created_at).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </div>
      </div>
    </div>
  );
})}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="p-3 flex gap-2 bg-white border-t">
        <input
          type="text"
          placeholder="Type a message..."
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          className="flex-1 border rounded-lg p-2"
        />
        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded-lg"
        >
          Send
        </button>
      </form>
    </div>
  );
}
